import static org.junit.Assert.*;

import org.junit.Test;

public class TestWebSearch {

	@Test
	public void test() {
	}

}
